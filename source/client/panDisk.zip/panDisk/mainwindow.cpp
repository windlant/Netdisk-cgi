﻿#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QPainter>
#include <QDesktopWidget>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    // 去掉边框
    this->setWindowFlags(windowFlags() | Qt::FramelessWindowHint);

    // 给菜单窗口传参
    ui->btn_group->setParent(this);
    // 处理所有信号
    managerSignals();
    // 默认显示我的文件窗口
    ui->stackedWidget->setCurrentWidget(ui->myfiles_page);

}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::showMainWindow()
{
    this->show();
    // 屏幕中间显示
    // 使用qApp->desktop();也可以
    QDesktopWidget* desktop = QApplication::desktop();
    // 移动窗口
    this->move((desktop->width() - desktop->width())/2, (desktop->height() - desktop->height())/2);
    //默认页面
    ui->btn_group->defaulfPage();
    // 切换到我的文件页面
    ui->stackedWidget->setCurrentWidget(ui->myfiles_page);
    ui->myfiles_page->getUserFilesList();

}

// 处理信们
void MainWindow::managerSignals()
{
    // 关闭
    connect(ui->btn_group, &ButtonGroup::closeWindow, this, &MainWindow::close);
    // 最大化
    connect(ui->btn_group, &ButtonGroup::maxWindow, [=]()
    {
        static bool flag = false;
        if(!flag)
        {
            this->showMaximized();
            flag = true;
        }
        else
        {
            this->showNormal();
            flag = false;
        }
    });

    connect(ui->btn_group, &ButtonGroup::minWindow, this, &MainWindow::showMinimized);
    connect(ui->btn_group, &ButtonGroup::sigMyFile, [=]()
    {
        ui->stackedWidget->setCurrentWidget(ui->myfiles_page);
        ui->myfiles_page->getUserFilesList();
    });

    connect(ui->btn_group, &ButtonGroup::sigTransform, [=]()
    {
        ui->stackedWidget->setCurrentWidget(ui->transfer_page);
    });
    // 切换用户
    connect(ui->btn_group, &ButtonGroup::sigSwitchUser, [=]()
    {
        loginAgain();
    });

    connect(ui->myfiles_page, &FilePage::gotoTransfer, [=](TransferStatus status)
    {
        ui->btn_group->slotButtonClick(Page::TRANSFER);
        if(status == TransferStatus::Uplaod)
        {
            ui->transfer_page->showUpload();
        }
        else if(status == TransferStatus::Download)
        {
            ui->transfer_page->showDownload();
        }
    });

}

void MainWindow::loginAgain()
{
    emit changeUser();
    ui->myfiles_page->clearAllTask();

}

void MainWindow::paintEvent(QPaintEvent *)
{
    QPainter painter(this);
}
