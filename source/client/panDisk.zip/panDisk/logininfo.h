﻿#ifndef LOGININFOINSTANCE_H
#define LOGININFOINSTANCE_H

#include <QString>
#include "fileinfo.h"

class LoginInfoInstance
{
public:
     static LoginInfoInstance *getInstance(); //保证唯一一个实例
     static void destroy(); //释放堆区空间

     void setLoginInfo( QString tmpUser, QString tmpIp, QString tmpPort,  QString token="");//设置登陆信息
     QString getUser() const;   //获取登陆用户
     QString getIp() const;     //获取服务器ip
     QString getPort() const;   //获取服务器端口
     QString getToken() const;  //获取登陆token

private:

    LoginInfoInstance();
    ~LoginInfoInstance();

    LoginInfoInstance(const LoginInfoInstance&);
    LoginInfoInstance& operator=(const LoginInfoInstance&);
    class Garbo
    {
    public:
        ~Garbo()
        {
            LoginInfoInstance::destroy();
        }
    };
    static Garbo tmp;

    static LoginInfoInstance *instance;


    QString user;   //当前登陆用户
    QString token;  //登陆token
    QString ip;     //web服务器ip
    QString port;   //web服务器端口
};

#endif // LOGININFOINSTANCE_H
