﻿#include "transfer.h"
#include "ui_transfer.h"
#include "downloadlayout.h"
#include "uploadlayout.h"
#include "logininfo.h"
#include <QFile>

Transfer::Transfer(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Transfer)
{
    ui->setupUi(this);

    // 设置上传布局实例
    UploadLayout *uploadLayout = UploadLayout::getInstance();
    uploadLayout->setUploadLayout(ui->upload_scroll);

    // 设置下载布局实例
    DownloadLayout *downloadLayout = DownloadLayout::getInstance();
    downloadLayout->setDownloadLayout(ui->download_scroll);

    ui->tabWidget->setCurrentIndex(0);

    // 切换tab页
    connect(ui->tabWidget, &QTabWidget::currentChanged, [=](int index)
    {
        if(index == 0) //上传
        {
            emit currentTabSignal("正在上传");
        }
        else if(index == 1)//下载
        {
             emit currentTabSignal("正在下载");
        }
    });

    ui->tabWidget->tabBar()->setStyleSheet(
       "QTabBar::tab{"
       "background-color: rgb(220, 220, 220));"
       "border-right: 1px solid gray;"
       "padding: 6px"
       "}"
       "QTabBar::tab:selected, QtabBar::tab:hover {"
       "background-color: rgb(173, 173, 173);"
       "}"
    );

}

Transfer::~Transfer()
{
    delete ui;
}


void Transfer::showUpload()
{
    ui->tabWidget->setCurrentWidget(ui->upload);
}

void Transfer::showDownload()
{
    ui->tabWidget->setCurrentWidget(ui->download);
}
