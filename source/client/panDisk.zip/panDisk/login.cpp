﻿#include "login.h"
#include "ui_login.h"
#include <QPainter>
#include <QDebug>
#include <QMessageBox>
#include <QRegExp>
#include <QJsonDocument>
#include <QJsonObject>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QUrl>
#include <string>
#include <QFile>
#include <QDir>
#include "logininfo.h"
using namespace std;

QString readFromJson(QString title, QString key, QString path = "conf.json")
{
    cout << "path : " << path;
    QFile file(path);
    cout << "QDir::currentPath()	 " << QDir::currentPath()	;


    if( false == file.open(QIODevice::ReadOnly) )
    {
        cout << "file open err";
        return "";
    }

    QByteArray json = file.readAll(); // 读取所有内容
    file.close(); // 关闭文件

    QJsonParseError error;
    QJsonDocument doc = QJsonDocument::fromJson(json, &error);
    if (error.error == QJsonParseError::NoError) // 没有出错
    {
        if (doc.isNull() || doc.isEmpty())
        {
            return "";
        }

        if( doc.isObject())
        {
            QJsonObject obj = doc.object();

            QJsonObject tmp = obj.value( title ).toObject();
            QStringList list = tmp.keys();
            for(int i = 0; i < list.size(); ++i)
            {
                if( list.at(i) == key )
                {
                    return tmp.value( list.at(i) ).toString();
                }
            }

        }
    }
    else
    {
        cout << "err = " << error.errorString();
    }

    return "";
}

Login::Login(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Login)
{
    ui->setupUi(this);

    m_manager = new QNetworkAccessManager;

    m_mainWin = new MainWindow;

    this->setWindowFlags(this->windowFlags() | Qt::FramelessWindowHint);

    this->setFont(QFont("新宋体", 12, QFont::Bold, false));

    ui->log_pwd->setEchoMode(QLineEdit::Password);
    ui->reg_pwd->setEchoMode(QLineEdit::Password);
    ui->reg_surepwd->setEchoMode(QLineEdit::Password);

    ui->stackedWidget->setCurrentIndex(0);
    ui->log_usr->setFocus();

    ui->log_pwd->setToolTip("至少包含大写 小写 数字 其他字符中的三种,字符个数至少 12");
    ui->reg_pwd->setToolTip("至少包含大写 小写 数字 其他字符中的三种,字符个数至少 12");
    ui->reg_surepwd->setToolTip("至少包含大写 小写 数字 其他字符中的三种,字符个数至少 12");
    ip = readFromJson("server", "ip");
    port = readFromJson("server", "port");

    connect(ui->log_register_btn, &QToolButton::clicked, [=]()
    {

        ui->stackedWidget->setCurrentWidget(ui->register_page);
        ui->reg_usr->setFocus();
    });

    connect(m_mainWin, &MainWindow::changeUser, [=]()
    {
        m_mainWin->hide();
        this->show();
    });
}

Login::~Login()
{
    delete ui;
}




QString getStrMd5(QString str)
{
    QByteArray array;
    array = QCryptographicHash::hash ( str.toLocal8Bit(), QCryptographicHash::Md5 );
    return array.toHex();
}

// 登陆用户需要使用的json数据包
QByteArray Login::setLoginJson(QString user, QString pwd)
{
    QMap<QString, QVariant> login;
    login.insert("username", user);
    login.insert("pwd", pwd);

    /*json数据如下
        {
            user:xxxx,
            pwd:xxx
        }
    */

    QJsonDocument jsonDocument = QJsonDocument::fromVariant(login);
    if ( jsonDocument.isNull() )
    {
        cout << " jsonDocument.isNull() ";
        return "";
    }

    return jsonDocument.toJson();
}

// 注册用户需要使用的json数据包
QByteArray Login::setRegisterJson(QString userName, QString nickName, QString firstPwd, QString phone, QString email)
{
    QMap<QString, QVariant> reg;
    reg.insert("username", userName);
    reg.insert("nickName", nickName);
    reg.insert("pwd", firstPwd);
    reg.insert("phone", phone);
    reg.insert("email", email);

    /*json数据如下
        {
            userName:xxxx,
            nickName:xxx,
            firstPwd:xxx,
            phone:xxx,
            email:xxx
        }
    */
    QJsonDocument jsonDocument = QJsonDocument::fromVariant(reg);
    if ( jsonDocument.isNull() )
    {
        cout << " jsonDocument.isNull() ";
        return "";
    }

    //cout << jsonDocument.toJson().data();

    return jsonDocument.toJson();
}

// 得到服务器回复的登陆状态， 状态码返回值为 "000", 或 "001"，还有登陆section
QStringList Login::getLoginStatus(QByteArray json)
{
    QJsonParseError error;
    QStringList list;

    // 将来源数据json转化为JsonDocument
    // 由QByteArray对象构造一个QJsonDocument对象，用于我们的读写操作
    QJsonDocument doc = QJsonDocument::fromJson(json, &error);
    if (error.error == QJsonParseError::NoError)
    {
        if (doc.isNull() || doc.isEmpty())
        {
            cout << "doc.isNull() || doc.isEmpty()";
            return list;
        }

        if( doc.isObject() )
        {
            //取得最外层这个大对象
            QJsonObject obj = doc.object();
            cout << "服务器返回的数据" << obj;
            //状态码
            list.append( obj.value( "code" ).toString() );
            //登陆token
            list.append( obj.value( "token" ).toString() );
        }
    }
    else
    {
        cout << "err = " << error.errorString();
    }

    return list;
}

// 画背景图片
void Login::paintEvent(QPaintEvent *)
{
    QPainter painter(this);
    QPixmap pixmap(":/images/login_bk.jpg");
    painter.drawPixmap(0, 0, width(), height(), pixmap);
}

// 用户登录操作
void Login::on_login_btn_clicked()
{
    // 获取用户登录信息
    QString user = ui->log_usr->text();
    QString pwd = ui->log_pwd->text();


    QByteArray array = setLoginJson(user, getStrMd5(pwd));

    QNetworkRequest request;
    QString url = QString("http://%1:%2/cgi-bin/src/Windows-login.cgi").arg(ip).arg(port);
    request.setUrl(QUrl(url));

    request.setHeader(QNetworkRequest::ContentTypeHeader, QVariant("application/json"));
    request.setHeader(QNetworkRequest::ContentLengthHeader, QVariant(array.size()));

    QNetworkReply* reply = m_manager->post(request, array);
    cout << "post url:" << url << "post data: " << array;

    connect(reply, &QNetworkReply::finished, [=]()
    {
        // 出错了
        if (reply->error() != QNetworkReply::NoError)
        {
            cout << reply->errorString();
            //释放资源
            reply->deleteLater();
            return;
        }

        // 将server回写的数据读出
//        QByteArray json = reply->readAll();
        QByteArray jsonData = reply->readAll();
        QJsonParseError error;
        QJsonDocument doc = QJsonDocument::fromJson(jsonData, &error);
        int result = -1;
         QString token = "";
        if (error.error == QJsonParseError::NoError)
        {
            if (doc.isNull() || doc.isEmpty())
            {
                cout << "doc.isNull() || doc.isEmpty()";
            }

            if( doc.isObject() )
            {
                // 取得最外层这个大对象
                QJsonObject obj = doc.object();
                result = obj.value( "result" ).toInt();
                token = obj.value( "token" ).toString();
            }
        }
        if( result == 0 )
        {
            cout << "登陆成功";

            // 设置登陆信息，显示文件列表界面需要使用这些信息
            LoginInfoInstance *p = LoginInfoInstance::getInstance(); //获取单例
            p->setLoginInfo(user, ip, port, token);
            cout << p->getUser().toUtf8().data() << ", " << p->getIp() << ", " << p->getPort() << token;

            // 当前窗口隐藏
            this->hide();
            // 主界面窗口显示
            m_mainWin->showMainWindow();
        }
        else if (result == 1)
        {
            QMessageBox::warning(this, "登录失败", "用户名不存在！！！");
        } else if (result == 2)
        {
            QMessageBox::warning(this, "登录失败", "密码错误！！！");
        }

        reply->deleteLater(); //释放资源
    });
}
int check_pwd(string pwd)
{
    int len  = pwd.length();
    if(len < 12)
        return 0;

    int daxie, xiaoxie, shuzi, qita;
    daxie = 0;
    xiaoxie = 0;
    shuzi = 0;
    qita = 0;
    for(int i = 0 ;i < len; i++)
    {
        char c = pwd[i];
        if(c >= 48 && c<=57)
            shuzi = 1;
        else if(c >= 65 && c <= 90)
            daxie = 1;
        else if(c >= 97 && c <=122)
            xiaoxie = 1;
        else
            qita = 1;
    }

    int sum = daxie + xiaoxie + shuzi + qita;
    if(sum < 3)
        return 0;
    return 1;
}

// 用户注册操作
void Login::on_register_btn_clicked()
{
    // 从控件中取出用户输入的数据
    QString userName = ui->reg_usr->text();
    QString firstPwd = ui->reg_pwd->text();
    QString surePwd = ui->reg_surepwd->text();

    if(!check_pwd(firstPwd.toStdString()))
    {
        QMessageBox::warning(this, "警告", "密码格式不正确");
        ui->reg_pwd->clear();
        ui->reg_pwd->setFocus();
        return;
    }


    if(surePwd != firstPwd)
    {
        QMessageBox::warning(this, "警告", "两次输入的密码不匹配, 请重新输入");
        ui->reg_surepwd->clear();
        ui->reg_surepwd->setFocus();
        return;
    }

    // 将注册信息打包为json格式
    QByteArray array;
    QMap<QString, QVariant> reg;
    reg.insert("username", userName);
    reg.insert("pwd",  getStrMd5(firstPwd));
    QJsonDocument jsonDocument = QJsonDocument::fromVariant(reg);
    if ( jsonDocument.isNull() )
    {
        cout << " jsonDocument.isNull() ";
        array =  "";
    }
    array =  jsonDocument.toJson();
    qDebug() << "register json data" << array;
    // 设置连接服务器要发送的url
    QNetworkRequest request;
    QString url = QString("http://%1:%2/cgi-bin/src/Windows-register.cgi").arg(ip).arg(port);

    qDebug() << "url:" << url;

    request.setUrl(QUrl(url));
    // 设置请求头
    request.setHeader(QNetworkRequest::ContentTypeHeader, QVariant("application/json"));
    request.setHeader(QNetworkRequest::ContentLengthHeader, QVariant(array.size()));
    // 发送数据
    QNetworkReply* reply = m_manager->post(request, array);


    // 判断请求是否被成功处理
    connect(reply, &QNetworkReply::readyRead, [=]()
    {
         cout << "connect" << endl;
        // 读sever回写的数据
        QByteArray jsonData = reply->readAll();
        QJsonParseError error;
        QJsonDocument doc = QJsonDocument::fromJson(jsonData, &error);
        int result;
        QString errmsg = "";
        if (error.error == QJsonParseError::NoError)
        {
            if (doc.isNull() || doc.isEmpty())
            {
                cout << "doc.isNull() || doc.isEmpty()";
            }

            if( doc.isObject() )
            {
                // 取得最外层这个大对象
                QJsonObject obj = doc.object();
                cout << "regRetunJson[msg] : " << obj.value( "msg" ).toString() << endl;
                cout << "regRetunJson[rsult] : " << obj.value( "result" ).toInt() << endl;
                result = obj.value( "result" ).toInt();
                errmsg = obj.value("msg").toString();
            }
        }
        if(0 == result)
        {
            QMessageBox::information(this, "注册成功", "注册成功，请登录");
            ui->reg_usr->clear();
            ui->reg_pwd->clear();
            ui->reg_surepwd->clear();
            ui->log_usr->setText(userName);
            ui->log_pwd->setText(firstPwd);
            ui->stackedWidget->setCurrentWidget(ui->login_page);
        } else {
            QMessageBox::warning(this, "注册失败", errmsg);
        }
        delete reply;
    });
}

