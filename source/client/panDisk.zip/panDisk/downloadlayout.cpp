﻿#include "downloadlayout.h"

DownloadLayout * DownloadLayout::instance = new DownloadLayout;

DownloadLayout::Garbo DownloadLayout::temp;

DownloadLayout * DownloadLayout::getInstance()
{
    return instance;
}

//设置布局
void DownloadLayout::setDownloadLayout(QWidget *p)
{
    m_wg = new QWidget(p);
    QLayout* layout = p->layout();
    layout->addWidget(m_wg);
    layout->setContentsMargins(0, 0, 0, 0);
    QVBoxLayout* vlayout = new QVBoxLayout;
    m_wg->setLayout(vlayout);
    vlayout->setContentsMargins(0, 0, 0, 0);
    m_layout = vlayout;

    vlayout->addStretch();
}

//获取布局
QLayout *DownloadLayout::getDownloadLayout()
{
    return m_layout;
}

