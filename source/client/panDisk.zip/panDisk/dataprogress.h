﻿#ifndef DATAPROGRESS_H
#define DATAPROGRESS_H
#include <QWidget>

namespace Ui {
class DataProgress;
}

//上传，下载进度控件
class DataProgress : public QWidget
{
    Q_OBJECT

public:
    explicit DataProgress(QWidget *parent = 0);
    ~DataProgress();

    void setFileName(QString name = "测试");
    void setProgress(int value = 0, int max = 100);

private:
    Ui::DataProgress *ui;
};

#endif // DATAPROGRESS_H
