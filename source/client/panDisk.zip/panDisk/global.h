﻿#ifndef GLOBAL_H
#define GLOBAL_H
#if _MSC_VER >=1600
#pragma execution_character_set("utf-8")
#endif

// 正则表达式字符串


#endif // GLOBAL_H
