﻿#ifndef DOWNLOADTASK_H
#define DOWNLOADTASK_H
#if _MSC_VER >=1600
#pragma execution_character_set("utf-8")
#endif

#include "fileinfo.h"

#include <QVBoxLayout>
#include <QUrl>
#include <QFile>
#include "dataprogress.h"
#include <QList>

//下载文件信息
struct DownloadInfo
{
    QFile *file;        //文件指针
    QString user;       //下载用户
    QString fileName;   //文件名字
    QString md5;        //文件md5
    QString localDir;
    QString logicFile;
    QUrl url;           //下载网址
    bool isDownload;    //是否已经在下载
    DataProgress *dp;   //下载进度控件
    int tid = -1;
};


class DownloadTask
{
public:
    static DownloadTask *getInstance();

    void clearList(); //清空上传列表
    bool isEmpty();   //判断上传队列是否为空
    bool isDownload(); //是否有文件正在下载
    DownloadInfo *takeTask();
    void dealDownloadTask();
    int appendDownloadList( FileInfo *info, QString filePathName, QString logicDir);
int appendDownloadList(int tid, QString filePathName, QString logicFile);

private:
    DownloadTask()
    {
    }

    ~DownloadTask()
    {
    }


    static DownloadTask *instance;

    class Garbo
    {
    public:
        ~Garbo()
        {
          if(NULL != DownloadTask::instance)
          {
            DownloadTask::instance->clearList();//清空上传列表

            delete DownloadTask::instance;
            DownloadTask::instance = NULL;
          }
        }
    };

    static Garbo temp;

    QList <DownloadInfo *> list;


public:
    int downloadPause = 0;
    void  clearDownload();
};

#endif // DOWNLOADTASK_H
