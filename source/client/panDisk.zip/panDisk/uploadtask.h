﻿#ifndef UPLOADTASK_H
#define UPLOADTASK_H


#include <QVBoxLayout>
#include <QFile>
#include "dataprogress.h"
#include "fileinfo.h"
//上传文件信息
struct UploadFileInfo
{
    QString md5;        //文件md5码
    QFile *file;        //文件指针
    QString fileName;   //文件名字
    qint64 size;        //文件大小
    QString path;       //文件路径
    QString dstDir;
    bool isUpload;      //是否已经在上传
    DataProgress *dp;   //上传进度控件
    int tid = -1;
};

//上传任务列表类，单例模式，一个程序只能有一个上传任务列表
class UploadTask
{
public:
    static UploadTask *getInstance(); //保证唯一一个实例
    int appendUploadList(QString path, QString dstDir);
int appendUploadList(int tid, QString filename, QString localdir);
    bool isEmpty(); //判断上传队列释放为空
    bool isUpload(); //是否有文件正在上传
void  clearUpload();

    UploadFileInfo * takeTask();

    void dealUploadTask();

    void clearList(); //清空上传列表

private:
    UploadTask()    //构造函数为私有
    {
    }

    ~UploadTask()    //析构函数为私有
    {
    }

    static UploadTask *instance;
    class Garbo
    {
    public:
        ~Garbo()
        {
          if(NULL != UploadTask::instance)
          {
            UploadTask::instance->clearList();

            delete UploadTask::instance;
            UploadTask::instance = NULL;
          }
        }
    };

    static Garbo temp;

    QList <UploadFileInfo *> list;

public:
    int uploadPause = 0;
};

#endif // UPLOADTASK_H
