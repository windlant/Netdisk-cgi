﻿#ifndef FILEPAGE_H
#define FILEPAGE_H
#include <QWidget>
#include <QTimer>
#include "fileinfo.h"
#include "uploadtask.h"
#include <QTreeWidget>
#include <QTreeWidgetItem>
#include <QStandardItemModel>
#include "downloadtask.h"
namespace Ui {
class FilePage;
}

class FilePage : public QWidget
{
    Q_OBJECT

public:
    explicit FilePage(QWidget *parent = 0);
    ~FilePage();


    void initTree();
    void addDir(QString dir, int type);
    void refreshTreeModel();
    void rmdir();
    void slotCustomContextMenu(const QPoint &point);

    void onActionMkdir();
    void onActionRmdir();
    void onActionCopydir();
    void onActionCutdir();
    void onActionPastedir();
    void onActionDownloadFile();
    void onActionDownloadDir();
    void onActionRename();

    void onTreeViewMenuRequested(const QPoint &pos);
    void onActionUploadFile();
    void onActionUploadDir();
    void addUploadDirs(QString dstDir, QStandardItem* curItem);
    void mkdir(QStandardItem* curItem, QString newFolderPath, QString newFolderName);
    void clearTreeItems();

    void sendFinishDownload(int tid);

    void getTaskList();

    void getTaskJsonInfo(QByteArray data);

    void pauseDownload();

    void pauseUpload();

    QByteArray setDownloadJson(QString username, int tid, long long int offset, long long int size);
    int sendDownload(QByteArray array, QString url, int tid, int offset, int trans_size, QFile* file);
    QStringList getFileListUnderDir(const QString &dirPath, QString logicPath, QStandardItem* curItem);

    void addUploadFiles(QString dstDir);

    void uploadFilesAction();

    int* uploadFile(UploadFileInfo *info, int tid, int offset, int size);

    void getUserFilesList();

    void getFileJsonInfo(QByteArray data);

    void addDownloadFiles();

    void downloadFilesAction();

    void clearAllTask();

    void checkTaskList();


signals:
    void loginAgainSignal();
    void gotoTransfer(TransferStatus status);


private:
    Ui::FilePage *ui;

    QStandardItemModel* treeModel;

    QList<QStandardItem*> treeItemList;

    QString curCopyDir;

    QString curDirType = "";

    QNetworkAccessManager* m_manager;

    QTimer m_uploadFileTimer;       //定时检查上传队列是否有任务需要上传
    QTimer m_downloadTimer;         //定时检查下载队列是否有任务需要下载

    QList<QString> dirList;    //文件列表
    QList<QString> fileList;    //文件列表


};

#endif
