﻿#ifndef FILEINFO_H
#define FILEINFO_H
#include <QDebug>
#include <QWidget>
#include <QString>
#include <QListWidgetItem>
#include <QNetworkAccessManager>

#define cout qDebug() << "[ " << __FILE__ << ":"  << __LINE__ << " ] "  
struct FileInfo
{
    QString md5;            // 文件md5码
    QString fileName;       // 文件名字
    QString user;           // 用户
    QString createTime;     // 上传时间
    QString url;            // url
    QString type;           // 文件类型
    qint64 size;            // 文件大小
    int shareStatus;        // 是否共享, 1共享， 0不共享
    int pv;                 // 下载量
    QListWidgetItem *item;  // list widget 的item
};
// 传输状态
enum TransferStatus{Download, Uplaod, Recod};

#endif // COMMON_H

