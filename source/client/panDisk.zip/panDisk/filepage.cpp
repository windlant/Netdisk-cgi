﻿#include "filepage.h"
#include "ui_filepage.h"
#include <QFileDialog>
#include <QMessageBox>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QNetworkReply>
#include <QNetworkRequest>
#include <QListWidgetItem>
#include <QToolButton>
#include <QInputDialog>
#include <string.h>
#include <QMenu>
#include "logininfo.h"
#include "downloadtask.h"

#define PIECE_SIZE 2048 * 1024
#define TRANS_BUFF_SIZE 3072 * 1024
#define MAX_TRY 5
#define BEGIN_TOKEN "Content-Type: application/octet-stream"
#define FILE_END "------WebKitFordsjluagkhuffdsgaskddhadksghfgvfhsjavdskadasmBoundary"

FilePage::FilePage(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::FilePage)
{
    ui->setupUi(this);

    initTree();
    // http管理类对象
    m_manager =  new QNetworkAccessManager;
    ui->treeView->setContextMenuPolicy(Qt::CustomContextMenu);
    connect(ui->treeView, &QTreeView::customContextMenuRequested, this, &FilePage::onTreeViewMenuRequested);
    // 定时检查任务队列
    checkTaskList();
    connect(ui->refreshButton, &QToolButton::clicked, [=]()
    {
        getUserFilesList();
    });

    connect(ui->getTaskButton, &QToolButton::clicked, [=]()
    {
        getTaskList();
    });

    connect(ui->pauseUpload, &QToolButton::clicked, [=]()
    {
        pauseUpload();
    });

    connect(ui->pauseDownload, &QToolButton::clicked, [=]()
    {
        pauseDownload();
    });
}


FilePage::~FilePage()
{
    delete ui;
}


QString getFileMd5(QString filePath)
{
    QFile localFile(filePath);

    if (!localFile.open(QFile::ReadOnly))
    {
        qDebug() << "file open error.";
        return 0;
    }

    QCryptographicHash ch(QCryptographicHash::Md5);

    quint64 totalBytes = 0;
    quint64 bytesWritten = 0;
    quint64 bytesToWrite = 0;
    quint64 loadSize = 1024 * 4;
    QByteArray buf;

    totalBytes = localFile.size();
    bytesToWrite = totalBytes;

    while (1)
    {
        if(bytesToWrite > 0)
        {
            buf = localFile.read(qMin(bytesToWrite, loadSize));
            ch.addData(buf);
            bytesWritten += buf.length();
            bytesToWrite -= buf.length();
            buf.resize(0);
        }
        else
        {
            break;
        }

        if(bytesWritten == totalBytes)
        {
            break;
        }
    }

    localFile.close();
    QByteArray md5 = ch.result();
    return md5.toHex();
}

void FilePage::pauseUpload()
{
    UploadTask *uploadList = UploadTask::getInstance();
    if(uploadList == NULL) {
        cout << "UploadTask::getInstance() == NULL";
        return;
    }
//    uploadList->uploadPause = uploadList->uploadPause ^ 1;
    if (uploadList->uploadPause == 1) {
        uploadList->uploadPause = 0;
        uploadList->clearUpload();
    } else {
        uploadList->uploadPause = 1;
    }
    cout << "uploadList->uploadPause change to " <<uploadList->uploadPause;
}

void FilePage::pauseDownload()
{
    DownloadTask *p = DownloadTask::getInstance();
    if(p == NULL) {
        cout << "DownloadTask::getInstance() == NULL";
        return;
    }
    if (p->downloadPause == 1) {
        p->downloadPause = 0;
        p->clearDownload();
    } else {
        p->downloadPause = 1;
    }
    cout << "p->downloadPause change to " << p->downloadPause;
//    p->downloadPause = p->downloadPause ^ 1;
}





void FilePage::addUploadFiles(QString dstDir)
{
    emit gotoTransfer(TransferStatus::Uplaod);
    //获取上传列表实例
    UploadTask *uploadList = UploadTask::getInstance();
    if(uploadList == NULL) {
        cout << "UploadTask::getInstance() == NULL";
        return;
    }

    QStringList list = QFileDialog::getOpenFileNames();
    for(int i = 0; i < list.size(); ++i) {
        int res = uploadList->appendUploadList(list.at(i), dstDir);
        if(res == -1) {

        }
        else if(res == -2) {

        }
        else if(res == -3) {
            cout << "打开文件失败";
        }
        else if(res == -4) {
            cout << "获取布局失败";
        }
    }
}

void FilePage::addUploadDirs(QString dstDir, QStandardItem* curItem)
{

    QString selectDir = QFileDialog::getExistingDirectory();
    cout << "logic path : " << dstDir << endl;
    cout << "将要上传的文件夹 " << selectDir << endl;
    getFileListUnderDir(selectDir, dstDir, curItem);


}

QStringList FilePage::getFileListUnderDir(const QString &dirPath, QString logicPath, QStandardItem* curItem)
{

    QStringList fileList;
    QDir dir(dirPath);
    QFileInfoList fileInfoList = dir.entryInfoList(QDir::Files | QDir::NoDotAndDotDot | QDir::Dirs);
    UploadTask *uploadList = UploadTask::getInstance();

    QString newLogicPath;
    if (logicPath == "/") {
        newLogicPath = logicPath + dir.dirName();
    } else {
        newLogicPath = logicPath + "/" + dir.dirName();
    }
    mkdir(curItem, newLogicPath, dir.dirName());

    foreach (auto fileInfo, fileInfoList) {
        QString filePath = newLogicPath + "/" + fileInfo.fileName();
        if(fileInfo.isDir())
        {
            getFileListUnderDir(fileInfo.absoluteFilePath(), newLogicPath, curItem);
        }

        if(fileInfo.isFile())
        {
            int res = uploadList->appendUploadList(fileInfo.absoluteFilePath(), newLogicPath);
            if(res == -1) {

            }
            else if(res == -2) {
                QMessageBox::warning(this, "添加失败", "要上传的文件 " + fileInfo.fileName() + " 已在上传队列中");
            }
            else if(res == -3) {
                cout << "打开文件失败";
            }
            else if(res == -4) {
                cout << "获取布局失败";
            }
        }
    }
    return fileList;
}

// 上传文件处理，取出上传任务列表的队首任务，上传完后，再取下一个任务
void FilePage::uploadFilesAction()
{
    // 获取上传列表实例
    UploadTask *uploadList = UploadTask::getInstance();
    if(uploadList == NULL) {
        cout << "UploadTask::getInstance() == NULL";
        return;
    }

    // 如果队列为空，无上传任务，终止程序
    if( uploadList->isEmpty() ) {
        return;
    }

    // 查看是否有上传任务，单任务上传，当前有任务，不能上传
    if( uploadList->isUpload() ) {
        return;
    }

    // 获取登陆信息实例
    LoginInfoInstance *login = LoginInfoInstance::getInstance(); //获取单例
    // url
    QNetworkRequest request;
    QString url = QString("http://%1:%2/cgi-bin/src/Windows-create-task.cgi").arg( login->getIp() ).arg( login->getPort() );
    request.setUrl( QUrl( url )); //设置url
    request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");

    // 取出第0个上传任务，如果任务队列没有任务在上传，设置第0个任务上传
    UploadFileInfo *info = uploadList->takeTask();

    // post数据包
    QByteArray array;
    QMap<QString, QVariant> tmp;
    tmp.insert("username", login->getUser());
    tmp.insert("type", "file_up");
    tmp.insert("token", login->getToken());
    if (info->tid == -1) {
        tmp.insert("md5", info->md5);
        tmp.insert("filename", info->fileName);
        tmp.insert("local_dir", info->path);
        tmp.insert("dst_dir", info->dstDir);
        tmp.insert("ftype", "0");
        tmp.insert("size", info->size);
    } else {
        tmp.insert("tid", info->tid);
    }

    QJsonDocument jsonDocument = QJsonDocument::fromVariant(tmp);
    if ( jsonDocument.isNull() ) {
        cout << " jsonDocument.isNull() ";
        array = "";
    }

    //cout << jsonDocument.toJson().data();

    array = jsonDocument.toJson();

    //uploadFile(info);
    // 发送post请求
    QNetworkReply *reply = m_manager->post(request, array);
    cout << "post url:" << url << "post data: " << array;

    if(reply == NULL) {
        cout << "reply is NULL";
        return;
    }

    //     信号和槽连接
    connect(reply, &QNetworkReply::finished, [=]() {
        if (reply->error() != QNetworkReply::NoError) { //有错误
            cout << reply->errorString();
            reply->deleteLater(); //释放资源
            return;
        }

        QByteArray array = reply->readAll();
        cout << array.data();
        reply->deleteLater(); //释放资源

        QJsonParseError error;
        QJsonDocument doc = QJsonDocument::fromJson(array, &error);
        int result = -1;
        int offset = 0;
        int uploadSize = 0;
        int tid = -1;
        if (error.error == QJsonParseError::NoError) {
            if (doc.isNull() || doc.isEmpty()) {
                cout << "doc.isNull() || doc.isEmpty()";
            }
            else if( doc.isObject() ) {
                // 取得最外层这个大对象
                QJsonObject obj = doc.object();
                result = obj.value( "result" ).toInt();
                offset = obj.value( "offset" ).toInt();
                uploadSize = obj.value( "size" ).toInt();
                tid = obj.value( "tid" ).toInt();
            }
        }
        else {
            cout << "err = " << error.errorString();
        }
        switch(result) {
        case 0:
            //秒传文件成功
            uploadList->dealUploadTask();
            break;
        case 1: {
            while (1) {
                int* ret = uploadFile(info, tid, offset, uploadSize);
                if (ret[0] == 1) {
                    offset = ret[1];
                    uploadSize = ret[2];
                    info->dp->setProgress(offset, info->size);
                    delete ret;
                }
                else {
                    cout << "ret[0] : " << ret[0] << endl;
                    if (ret[0] == -2) {
                        cout << "pauseUpload " << info->fileName;
                        delete ret;
                        return;
                    }
                    delete ret;
                    info->dp->setProgress(100, 100);
                    //获取上传列表实例
                    UploadTask *uploadList = UploadTask::getInstance();
                    if(uploadList == NULL) {
                        cout << "UploadTask::getInstance() == NULL";
                        return;
                    }

                    uploadList->dealUploadTask(); //删除已经完成的上传任务
                    return;
                }

            }
            break;
        }
        case 3:
            // 没有该目录(不可能出现这个错误)
            break;
        case 4:
            uploadList->dealUploadTask();
            break;
        case 2:
            QMessageBox::warning(this, "账户异常", "请重新登陆！！！");
            emit loginAgainSignal(); //发送重新登陆信号
            return;
        default:
            break;
        }
    });
}

// 上传真正的文件内容，不能秒传的前提下
int* FilePage::uploadFile(UploadFileInfo *info, int tid, int offset, int size)
{
    int* ret = new int[3];
    ret[0] = -1;
    // 获取上传列表实例
    UploadTask *uploadList = UploadTask::getInstance();
    if(uploadList == NULL) {
        cout << "UploadTask::getInstance() == NULL";
        ret[0] = -2;
        return ret;
    }
    if (uploadList->uploadPause == 1) {
        ret[0] = -2;
        return ret;

    }

    cout << "uploadFile : " << info->fileName << endl;


    //取出上传任务
    QFile *file = info->file;           //文件指针
    QString fileName = info->fileName;  //文件名字
    QString md5 = info->md5;            //文件md5码
    DataProgress *dp = info->dp;        //进度条控件
    QString boundary = QString("------WebKitFordsjluagkhuffdsgaskddhadksghfgvfhsjavdskadasmBoundary");   //产生分隔线

    //获取登陆信息实例
    LoginInfoInstance *login = LoginInfoInstance::getInstance(); //获取单例

    QByteArray data;

    /*
    ------WebKitFormBoundary88asdgewtgewx\r\n
    Content-Disposition: form-data; user="milo"; filename="xxx.jpg"; md5="xxxx"; size=10240\r\n
    Content-Type: application/octet-stream\r\n
    \r\n
    真正的文件内容\r\n
    ------WebKitFormBoundary88asdgewtgewx
    */

    //第1行，分隔线
    data.append(boundary);
    data.append("\r\n");

    //上传文件信息
    data.append("Content-Disposition: form-data; ");
    data.append( QString("tid=\"%1\" ").arg(tid) ); //涓婁紶鐢ㄦ埛
    data.append( QString("offset=\"%1\" ").arg(offset) ); //鏂囦欢鍚嶅瓧
    data.append( QString("size=\"%1\" ").arg(size)  );   //鏂囦欢澶у皬
    data.append("\r\n");

    data.append("Content-Type: application/octet-stream");
    data.append("\r\n");
    data.append("\r\n");

    // 上传文件内容
    file->seek(offset);
    QByteArray trueUpload = file->read(size);
    //qDebug() << "mid file " << trueUpload << endl;
    data.append( trueUpload ); //文件内容
    data.append("\r\n");

    // 结束分隔线
    data.append(boundary);
    //    cout << "fdsgtrhfbkglnkds.ld,saknr.f" << endl;
    //    qDebug() << data.data() << endl;
    QNetworkRequest request; //请求对象
    //http://127.0.0.1:80/upload

    QString url = QString("http://%1:%2/cgi-bin/src/Windows-upload.cgi").arg(login->getIp()).arg(login->getPort());
    request.setUrl(QUrl( url )); //设置url

    // qt默认的请求头
    //request.setRawHeader("Content-Type","text/html");
    request.setHeader(QNetworkRequest::ContentTypeHeader,"application/json");
    cout << "before 发送post upload请求" << endl;
    // 发送post请求
    QNetworkReply * reply = m_manager->post( request, data );
    cout << "after 发送post upload请求" << endl;
    if(reply == NULL) {
        cout << "reply == NULL";
    }


    QTimer timer;
    timer.setInterval(300000);  // 设置超时时间 30 秒
    timer.setSingleShot(true);  // 单次触发
    QEventLoop loop;
    connect(&timer, &QTimer::timeout, &loop, &QEventLoop::quit);
    connect(reply, &QNetworkReply::finished, &loop, &QEventLoop::quit);
    timer.start();
    loop.exec();  // 启动事件循环


    if (timer.isActive()) {  // 处理响应
        timer.stop();
        cout << "connect" << endl;

        // 出错了
        if (reply->error() != QNetworkReply::NoError) {
            cout << reply->errorString();
            //释放资源
            reply->deleteLater();

            return ret;
        }

        // 将server回写的数据读出
        //        QByteArray json = reply->readAll();
        QByteArray jsonData = reply->readAll();
        cout << "!!!!!!!!!!!!!!!uploadFile!!!!!!!!!!!!!" << endl;
        cout << jsonData << endl;

        reply->deleteLater(); //释放资源
        QJsonParseError error;
        QJsonDocument doc = QJsonDocument::fromJson(jsonData, &error);
        if (error.error == QJsonParseError::NoError) {
            if (doc.isNull() || doc.isEmpty()) {
                cout << "doc.isNull() || doc.isEmpty()";
            }
            else if( doc.isObject() ) {
                // 取得最外层这个大对象
                QJsonObject obj = doc.object();
                ret[0] = obj.value( "result" ).toInt();
                switch(ret[0]) {
                case 1:
                    ret[1] = obj.value( "offset" ).toInt();
                    ret[2] = obj.value( "size" ).toInt();
                    break;
                case 2:
                    ret[0] = -1;
                    break;
                default:
                    break;
                }

            }
        }
        else {
            cout << "err = " << error.errorString();
        }

        return ret;
    } else {  // 处理超时
        //disconnect(pReply, &QNetworkReply::finished, &loop, &QEventLoop::quit);
        reply->abort();
        reply->deleteLater();
        cout << "Timeout";
    }

    cout << "no no no no " << endl;
    return ret;

}


void FilePage::addDir(QString dir, int type)
{
    QStandardItem* rootItem = treeModel->invisibleRootItem()->child(0);
    if (dir == "/") {
        return;
    }
    QStringList dirs = dir.mid(1).split("/");
    cout << "QStringList dirs size" <<dirs.size() <<  endl;
    for (int i = 0; i < dirs.size(); i++) {
        cout << dirs.at(i) << " ";
    }

    int existDirCnt = 0;
    for (int i = 0; i < dirs.size(); i++) {
        int rowCount = rootItem->rowCount();
        int flag = 0;
        for (int i = 0; i < rowCount; ++i) {
            QStandardItem* curItem = rootItem->child(i);
            QString curDir = curItem->text();
            cout << "curDir : " << curDir;
            if (curDir == dirs.at(existDirCnt)) {
                flag = 1;
                existDirCnt++;
                rootItem = curItem;
                break;
            }
        }
        if (flag == 0) {
            break;
        }
    }
    cout << "existDirCnt : " << existDirCnt << endl;
    for (int i = existDirCnt; i < dirs.size(); ++i) {
        cout << "new dir " << i << dirs.at(i) << endl;
        QStandardItem * newItem = new QStandardItem(dirs.at(i));
        //        treeItemList.append(newItem);
        if (type == 0) {
            newItem->setIcon(QIcon(":/images/file-folder.jpeg"));
            newItem->setStatusTip("0");

        } else {
            newItem->setIcon(QIcon(":/images/file.jpeg"));
            newItem->setStatusTip("1");
        }

        newItem->setToolTip(dir);
        rootItem->appendRow(newItem);
        rootItem = newItem;
    }
    //    ui->treeView->setModel(treeModel);
}


void FilePage::initTree()
{
    //1，构造Model，这里示例具有3层关系的model构造过程
    treeModel = new QStandardItemModel(ui->treeView);
    //    treeModel->setHorizontalHeaderLabels(QStringList()<<QStringLiteral("目录") << QStringLiteral("文件名"));     //设置列头

    //2，给QTreeView应用model
    ui->treeView->setModel(treeModel);
    ui->treeView->setEditTriggers(QAbstractItemView::NoEditTriggers);
}

// 清空所有item项目
void FilePage::clearTreeItems()
{
    //    treeModel->clear();
    treeModel->removeRows(0, treeModel->rowCount());
    //    cout << "after treeModel->clear()";
    //    //使用QListWidget::count()来统计ListWidget中总共的item数目
    //    for(int i = treeItemList.size() - 1; i >= 0; --i) {
    //        cout << i << endl;
    //        QStandardItem* toDelete = treeItemList.at(i);
    //        cout << "after QStandardItem* toDelete ";
    //        try {
    //            delete toDelete;
    //        } catch () {

    //        }

    //    }
    //    treeItemList.clear();
}

void FilePage::refreshTreeModel()
{
    cout << "refreshTreeModel";

    clearTreeItems();
    //    dirList.clear();
    cout << "after clearTreeItems";
    QStandardItem * newItem = new QStandardItem("/");
    newItem->setIcon(QIcon(":/images/file-folder.jpeg"));
    newItem->setToolTip("/");
    newItem->setStatusTip("0");
    treeModel->appendRow(newItem);
    for(int i = 0; i < dirList.size(); ++i) {
        addDir(dirList.at(i), 0);
    }
    cout << "refreshTreeModel" << endl;
    for(int i = 0; i < fileList.size(); ++i) {
        addDir(fileList.at(i), 1);
    }
}

void FilePage::rmdir()
{
    // 当前结点的索引
    auto curIndex = ui->treeView->currentIndex();
    // 无效则不做处理
    if (!curIndex.isValid())
    {
        return;
    }
    // 当前结点
    auto curItem = treeModel->itemFromIndex(curIndex);
    // 当前结点的父结点
    auto parentItem = curItem->parent();
    // 如果父结点无效，则当前结点是顶级结点,直接使用model操作
    if (!parentItem)
    {
        treeModel->takeRow(curItem->row());
    }
    else
    {
        parentItem->takeRow(curItem->row());
    }
}



void FilePage::getTaskList()
{


    QNetworkRequest request; //请求对象

    // 获取登陆信息实例
    LoginInfoInstance *login = LoginInfoInstance::getInstance(); //获取单例
    QString url;

    QString tmp;
    url = QString("http://%1:%2/cgi-bin/src/Windows-get-task.cgi").arg(login->getIp()).arg(login->getPort());
    cout << " url: " << url;
    request.setUrl(QUrl( url )); //设置url

    request.setHeader(QNetworkRequest::ContentTypeHeader,"application/json");

    QByteArray data;
    QMap<QString, QVariant> tmp1;
    tmp1.insert("username", login->getUser());
    tmp1.insert("token", login->getToken());
    //    tmp.insert("start", start);
    //    tmp.insert("count", count);

    QJsonDocument jsonDocument = QJsonDocument::fromVariant(tmp1);
    if ( jsonDocument.isNull() ) {
        cout << " jsonDocument.isNull() ";
        data = "";
    }

    //cout << jsonDocument.toJson().data();

    data = jsonDocument.toJson();
    //改变文件起点位置
    //    m_start += m_count;
    //    m_userFilesCount -= m_count;

    //发送post请求
    QNetworkReply * reply = m_manager->post( request, data );
    if(reply == NULL) {
        cout << "reply == NULL";
        return;
    }

    //获取请求的数据完成时，就会发送信号SIGNAL(finished())
    connect(reply, &QNetworkReply::finished, [=]() {
        if (reply->error() != QNetworkReply::NoError) { //有错误
            cout << reply->errorString();
            reply->deleteLater(); //释放资源
            return;
        }

        //服务器返回用户的数据
        QByteArray array = reply->readAll();

        cout << " ========================: ";
        qDebug()<<array.length()<<"\t"<<array.data();
        cout << " ======================: ";

        reply->deleteLater();
        int result = 1;
        QJsonParseError error;
        QJsonDocument doc = QJsonDocument::fromJson(array, &error);
        if (error.error != QJsonParseError::NoError) {
            cout << "err = " << error.errorString();
            return;
        }
        if (doc.isNull() || doc.isEmpty()) {
            cout << "doc.isNull() || doc.isEmpty()";
            return;
        }

        QJsonObject obj = doc.object();
        result = obj.value( "result" ).toInt();

        if(result != 0) {
            QMessageBox::warning(this, "账户异常", "请重新登陆！！！");
            emit loginAgainSignal(); //发送重新登陆信号

            return; //中断
        }

        getTaskJsonInfo(array);
    });
}

void FilePage::getTaskJsonInfo(QByteArray data)
{
    QJsonParseError error;
    QJsonDocument doc = QJsonDocument::fromJson(data, &error);


    if (error.error != QJsonParseError::NoError) { //没有出错
        cout << "err = " << error.errorString();
        return;
    }
    if (doc.isNull() || doc.isEmpty()) {
        cout << "doc.isNull() || doc.isEmpty()";
        return;
    }

    if( doc.isObject()) {
        QJsonObject obj = doc.object();
        QJsonArray upTaskarray = obj.value("up_tasks").toArray();
        QJsonArray downTaskArray = obj.value("down_tasks").toArray();
        UploadTask *uploadList = UploadTask::getInstance();
        if(uploadList == NULL) {
            cout << "UploadTask::getInstance() == NULL";
            return;
        } else {
            for(int i = 0; i < upTaskarray.size(); ++i) {
                QJsonObject tmp = upTaskarray[i].toObject(); //取第i个对象
                QString filename = tmp.value("filename").toString();
                int tid = tmp.value("tid").toInt();
                QString localdir = tmp.value("local_dir").toString();
                int res = uploadList->appendUploadList(tid, filename, localdir);
                if(res == -3) {
                    cout << "打开文件失败";
                }
                else if(res == -4) {
                    cout << "获取布局失败";
                }
            }
        }

        DownloadTask *p = DownloadTask::getInstance();
        if(p == NULL) {
            cout << "DownloadTask::getInstance() == NULL";
            return;
        } else {
            for(int i = 0; i < downTaskArray.size(); ++i) {
                QJsonObject tmp = downTaskArray[i].toObject(); //取第i个对象
                QString logicfile = tmp.value("filename").toString();
                int tid = tmp.value("tid").toInt();
                QString localdir = tmp.value("local_dir").toString();
                int res = p->appendDownloadList(tid, localdir, logicfile); //追加到下载列表
                if(res == -2) { //打开文件失败
                    QMessageBox::warning(this, "打开文件失败", localdir);
                }
            }
        }
    }

}


void FilePage::getUserFilesList()
{


    QNetworkRequest request; //请求对象

    // 获取登陆信息实例
    LoginInfoInstance *login = LoginInfoInstance::getInstance(); //获取单例
    QString url;

    QString tmp;
    url = QString("http://%1:%2/cgi-bin/src/Windows-getfiles.cgi").arg(login->getIp()).arg(login->getPort());
    cout << " url: " << url;
    request.setUrl(QUrl( url )); //设置url

    //qt默认的请求头
    //request.setRawHeader("Content-Type","text/html");
    request.setHeader(QNetworkRequest::ContentTypeHeader,"application/json");

    QByteArray data;
    QMap<QString, QVariant> tmp1;
    tmp1.insert("username", login->getUser());
    tmp1.insert("token", login->getToken());
    //    tmp.insert("start", start);
    //    tmp.insert("count", count);

    QJsonDocument jsonDocument = QJsonDocument::fromVariant(tmp1);
    if ( jsonDocument.isNull() ) {
        cout << " jsonDocument.isNull() ";
        data = "";
    }

    //cout << jsonDocument.toJson().data();

    data = jsonDocument.toJson();

    //发送post请求
    QNetworkReply * reply = m_manager->post( request, data );
    if(reply == NULL) {
        cout << "reply == NULL";
        return;
    }

    //获取请求的数据完成时，就会发送信号SIGNAL(finished())
    connect(reply, &QNetworkReply::finished, [=]() {
        if (reply->error() != QNetworkReply::NoError) { //有错误
            cout << reply->errorString();
            reply->deleteLater(); //释放资源
            return;
        }

        //服务器返回用户的数据
        QByteArray array = reply->readAll();

        cout << " ========================: ";
        qDebug()<<array.length()<<"\t"<<array.data();
        cout << " ======================: ";

        reply->deleteLater();
        int result = 1;
        QJsonParseError error;
        QJsonDocument doc = QJsonDocument::fromJson(array, &error);
        if (error.error != QJsonParseError::NoError) {
            cout << "err = " << error.errorString();
            return;
        }
        if (doc.isNull() || doc.isEmpty()) {
            cout << "doc.isNull() || doc.isEmpty()";
            return;
        }
        QJsonObject obj = doc.object();
        result = obj.value( "result" ).toInt();
        if(result != 0) {
            QMessageBox::warning(this, "账户异常", "请重新登陆！！！");
            emit loginAgainSignal(); //发送重新登陆信号

            return; //中断
        }
        getFileJsonInfo(array);//解析文件列表json信息，存放在文件列表中
        refreshTreeModel();
    });
}

void FilePage::getFileJsonInfo(QByteArray data)
{
    QJsonParseError error;
    QJsonDocument doc = QJsonDocument::fromJson(data, &error);


    if (error.error != QJsonParseError::NoError) { //没有出错
        cout << "err = " << error.errorString();
        return;
    }
    if (doc.isNull() || doc.isEmpty()) {
        cout << "doc.isNull() || doc.isEmpty()";
        return;
    }

    if( doc.isObject()) {
        QJsonObject obj = doc.object();//取得最外层这个大对象
        QJsonArray array = obj.value("files").toArray();
        QJsonArray dirArray = obj.value("dirs").toArray();
        dirList.clear();
        fileList.clear();
        for(int i = 0; i < dirArray.size(); ++i) {
            QString dir = dirArray[i].toString();
            dirList.append(dir);
        }
        cout << "dirList : " << obj.value("dirs") << endl;
        for(int i = 0; i < array.size(); ++i) {
            QString filePath = array[i].toString();
            fileList.append(filePath);
        }
    }

}


// 下载文件处理，取出下载任务列表的队首任务，下载完后，再取下一个任务
void FilePage::downloadFilesAction()
{
    DownloadTask *p = DownloadTask::getInstance();
    if(p == NULL) {
        cout << "DownloadTask::getInstance() == NULL";
        return;
    }

    if( p->isEmpty() ) {
        return;
    }

    if( p->isDownload() ) {
        return;
    }


    DownloadInfo *tmp = p->takeTask(); //取下载任务

    QFile *file = tmp->file;

    QString filename = tmp->fileName;
    DataProgress *dp = tmp->dp;


    LoginInfoInstance *login = LoginInfoInstance::getInstance();

    QNetworkRequest request;
    QString url = QString("http://%1:%2/cgi-bin/src/Windows-create-task.cgi").arg( login->getIp() ).arg( login->getPort() );
    request.setUrl( QUrl( url ));
    request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");

    QMap<QString, QVariant> map;
    map.insert("username", login->getUser());
    map.insert("type", "file_down");
    map.insert("token", login->getToken());
    if (tmp->tid == -1) {
        map.insert("filename", tmp->logicFile);
        map.insert("local_dir", tmp->localDir);
    } else {
        map.insert("tid", tmp->tid);
    }

    QString localDir = tmp->localDir;
    cout << "localDir : " << localDir;
    QByteArray jsonArray;
    QJsonDocument jsonDocument = QJsonDocument::fromVariant(map);
    QByteArray array;
    if ( jsonDocument.isNull() ) {
        cout << " jsonDocument.isNull() ";
        array =  "";
    }


    array = jsonDocument.toJson();
    QNetworkReply *reply = m_manager->post(request, array);
    cout << "post url:" << url << "post data: " << array;

    if(reply == NULL) {
        p->dealDownloadTask(); //删除任务
        cout << "get err";
        return;
    }

    //     信号和槽连接
    connect(reply, &QNetworkReply::finished, [=]() {
        if (reply->error() != QNetworkReply::NoError) { //有错误
            cout << reply->errorString();
            reply->deleteLater(); //释放资源
            return;
        }



        QByteArray array = reply->readAll();
        cout << array.data();
        reply->deleteLater(); //释放资源
        QJsonParseError error;
        QJsonDocument doc = QJsonDocument::fromJson(array, &error);
        int result = -1;
        QString md5 = "";
        int fileSize = 0;
        int tid = -1;
        if (error.error == QJsonParseError::NoError) {
            if (doc.isNull() || doc.isEmpty()) {
                cout << "doc.isNull() || doc.isEmpty()";
            }
            else if( doc.isObject() ) {
                // 取得最外层这个大对象
                QJsonObject obj = doc.object();
                result = obj.value( "result" ).toInt();
                md5 = obj.value( "md5" ).toString();
                fileSize = obj.value( "filesize" ).toInt();
                tid = obj.value( "tid" ).toInt();
            }
        }
        else {
            cout << "err = " << error.errorString();
        }
        switch(result) {
        case 0: {
            // 下载任务创建完成

            QFile writeFile(localDir);
            if (writeFile.exists()) {
                QString local_md5 = getFileMd5(localDir);
                if(local_md5 == md5)
                {
                    sendFinishDownload(tid);
                    cout << "文件秒下" << endl;
                    dp->setProgress(100, 100);
                    cout << "before p->dealDownloadTask()" ;
                    p->dealDownloadTask();
                    cout << "after p->dealDownloadTask()" ;
                    if (file->isOpen()) {
                        file->close();
                    }
                    return;

                }
            }

            QString real_local_dir = localDir + ".tmp";
            long long int offset = 0;
            long long int trans_size = 0;

            //            QFile tmpFile(real_local_dir);

            if(file->exists())
            {
                if (!file->isOpen()) {
                    file->open(QIODevice::WriteOnly);
                }
                offset = file->size();
            }
            QString url1 = QString("http://%1:%2/cgi-bin/src/Windows-download.cgi").arg( login->getIp() ).arg( login->getPort() );
            while (offset < fileSize) {
                if(fileSize - offset > PIECE_SIZE)
                    trans_size = PIECE_SIZE;
                else
                    trans_size = fileSize - offset;

                QByteArray array1 = setDownloadJson(login->getUser(), tid, offset, trans_size);
                int write_size = sendDownload(array1, url1, tid, offset, trans_size, file);
                dp->setProgress(offset, fileSize);
                if (write_size == -2) {
                    cout << "pauseDownload" << localDir;
                }
                if(write_size != trans_size)
                {
                    cout<<"write_size != trans_size";
                    return;
                }

                offset += trans_size;
                if(offset > fileSize)//鍑洪敊
                {
                    cout<<"offset > fileSize";
                    return;
                }


            }

            sendFinishDownload(tid);
            dp->setProgress(100, 100);
            file->close();
            file->rename(localDir);
            p->dealDownloadTask();
            break;
        }
        case 1:
            QMessageBox::warning(this, "账户异常", "请重新登陆！！！");
            emit loginAgainSignal(); //发送重新登陆信号
            return;
        case 2:
            QMessageBox::information(this, "文件不已存在", QString("%1 不存在").arg(tmp->fileName));
            cout << QString("%1 不已存在").arg(tmp->fileName).toUtf8().data();
            break;

        default:
            break;
        }
    });

}

int FilePage::sendDownload(QByteArray array, QString url, int tid, int offset, int trans_size, QFile* file)
{
    DownloadTask *p = DownloadTask::getInstance();
    if(p == NULL) {
        cout << "DownloadTask::getInstance() == NULL";
        return -1;
    }
    if (p->downloadPause == 1) {
        return -2;
    }

    QNetworkRequest request;
    request.setUrl( QUrl( url )); //设置url
    request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");
    QNetworkReply *reply1 = m_manager->post(request, array);
    cout << "post url:" << url << "post data: " << array;

    QTimer timer;
    timer.setInterval(30000);  // 设置超时时间 30 秒
    timer.setSingleShot(true);  // 单次触发
    QEventLoop loop;
    connect(&timer, &QTimer::timeout, &loop, &QEventLoop::quit);
    connect(reply1, &QNetworkReply::finished, &loop, &QEventLoop::quit);
    timer.start();
    loop.exec();  // 启动事件循环


    if (timer.isActive()) {  // 处理响应
        timer.stop();
        //    connect(reply1, &QNetworkReply::finished, [=]() {
        if (reply1->error() != QNetworkReply::NoError) { //有错误
            cout << reply1->errorString();
            reply1->deleteLater(); //释放资源
            return -1;
        }

        QByteArray resp = reply1->readAll();
        reply1->deleteLater(); //释放资源
        QString tmpstr = QString(resp);
        cout << "resp" << tmpstr;
        QString paramString = tmpstr.mid(0,tmpstr.indexOf("\r\n"));
        QString paramTrim = paramString.trimmed();
        cout << "paramTrim : " << paramTrim;
        QStringList paramList = paramTrim.split("  ");
        cout << "paramList size : "  << paramList.size();
        QString d_tid_str = paramList.at(0);
        int d_tid = d_tid_str.mid(d_tid_str.indexOf("=") + 1).toInt();
        cout << "d_tid : " << d_tid;
        QString d_offset_str = paramList.at(1);
        int d_offset = d_offset_str.mid(d_offset_str.indexOf("=") + 1).toInt();
        cout << "d_offset : " << d_offset;
        QString d_size_str = paramList.at(2);
        int d_size = d_size_str.mid(d_size_str.indexOf("=") + 1).toInt();
        cout << "d_size : " << d_size;
        if(d_tid != tid)
        {
            cout<<"任务序号不匹配";
            return -1;
        }

        if (trans_size != d_size) {
            cout<<"trans_size不匹配d_size";
            return -1;
        }

        QByteArray fileContent = resp.mid(resp.indexOf(QString(BEGIN_TOKEN)) + QString(BEGIN_TOKEN).size() + 4);
        //        cout << "filebegin : " << resp.indexOf(QString(BEGIN_TOKEN)) + 4;
        file->seek(offset);
        int write_size = file->write(fileContent, d_size);
        return write_size;
        //    });
    }

    return -1;
}


QByteArray FilePage::setDownloadJson(QString username, int tid, long long int offset, long long int size)
{
    QMap<QString, QVariant> map;
    map.insert("username", username);
    map.insert("finish", 0);
    map.insert("tid", tid);
    map.insert("offset", offset);
    map.insert("size", size);
    QJsonDocument jsonDocument = QJsonDocument::fromVariant(map);
    if ( jsonDocument.isNull() ) {
        cout << " jsonDocument.isNull() ";
        return "";
    }
    return jsonDocument.toJson();

}


void FilePage::sendFinishDownload(int tid)
{
    LoginInfoInstance *login = LoginInfoInstance::getInstance(); //获取单例
    cout << "文件结束下载";
    QNetworkRequest request;
    QString url = QString("http://%1:%2/cgi-bin/src/Windows-download.cgi").arg( login->getIp() ).arg( login->getPort() );
    request.setUrl( QUrl( url )); //设置url
    request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");
    QMap<QString, QVariant> map;
    map.insert("username", login->getUser());
    map.insert("finish", 1);
    map.insert("tid", tid);
    QByteArray jsonArray;

    QJsonDocument jsonDocument = QJsonDocument::fromVariant(map);
    QByteArray array;
    if ( jsonDocument.isNull() ) {
        cout << " jsonDocument.isNull() ";
        array =  "";
    }

    //cout << jsonDocument.toJson().data();

    array = jsonDocument.toJson();
    //sendmsg(to_download_cgi, DOWNLOAD_FILE_API);

    QNetworkReply *reply = m_manager->post(request, array);
    cout << "post url:" << url << "post data: " << array;

    //     信号和槽连接
    connect(reply, &QNetworkReply::finished, [=]() {
        if (reply->error() != QNetworkReply::NoError) { //有错误
            cout << reply->errorString();
            reply->deleteLater(); //释放资源
            return;
        }

        QByteArray array = reply->readAll();
        cout << "sendFinishDownload : " << array.data();
        reply->deleteLater(); //释放资源
    });

}
void FilePage::clearAllTask()
{
    //获取上传列表实例
    UploadTask *uploadList = UploadTask::getInstance();
    if(uploadList == NULL) {
        cout << "UploadTask::getInstance() == NULL";
        return;
    }

    uploadList->clearList();

    //获取下载列表实例
    DownloadTask *p = DownloadTask::getInstance();
    if(p == NULL) {
        cout << "DownloadTask::getInstance() == NULL";
        return;
    }

    p->clearList();
}

// 定时检查处理任务队列中的任务
void FilePage::checkTaskList()
{
    //定时检查上传队列是否有任务需要上传
    connect(&m_uploadFileTimer, &QTimer::timeout, [=]() {
        //上传文件处理，取出上传任务列表的队首任务，上传完后，再取下一个任务
        uploadFilesAction();
    });

    // 启动定时器，500毫秒间隔
    // 每个500毫秒，检测上传任务，每一次只能上传一个文件
    m_uploadFileTimer.start(500);

    // 定时检查下载队列是否有任务需要下载
    connect(&m_downloadTimer, &QTimer::timeout, [=]() {
        // 上传文件处理，取出上传任务列表的队首任务，上传完后，再取下一个任务
        downloadFilesAction();
    });

    // 启动定时器，500毫秒间隔
    // 每个500毫秒，检测下载任务，每一次只能下载一个文件
    m_downloadTimer.start(500);
}


void FilePage::onTreeViewMenuRequested(const QPoint &pos)
{
    QModelIndex curIndex = ui->treeView->indexAt(pos);
    auto curItem = treeModel->itemFromIndex(curIndex);
    if (curIndex.isValid()) // 右键选中了有效index
    {
        //        QIcon view = QApplication::style()->standardIcon(QStyle::SP_MessageBoxInformation);
        //        QIcon test = QApplication::style()->standardIcon(QStyle::SP_DesktopIcon);

        // 创建菜单
        QMenu menu;
        if (curItem->statusTip() == "0") {
            menu.addAction(tr("添加文件夹"), this, &FilePage::onActionMkdir);
            menu.addSeparator();
            menu.addAction(tr("上传文件"), this, &FilePage::onActionUploadFile);
            menu.addSeparator();
            menu.addAction(tr("上传文件夹"), this, &FilePage::onActionUploadDir);
            menu.addSeparator();
            menu.addAction(tr("下载文件夹"), this, &FilePage::onActionDownloadDir);
            menu.addSeparator();
        } else if (curItem->statusTip() == "1"){
            menu.addAction(tr("重命名"), this, &FilePage::onActionRename);
            menu.addSeparator();
            menu.addAction(tr("下载文件"), this, &FilePage::onActionDownloadFile);
            menu.addSeparator();
        }

        menu.addAction(tr("删除"), this, &FilePage::onActionRmdir);
        menu.addSeparator();
        menu.addAction(tr("复制"), this, &FilePage::onActionCopydir);
        menu.addSeparator();
        menu.addAction(tr("剪切"), this, &FilePage::onActionCutdir);
        menu.addSeparator();
        menu.addAction(tr("粘贴"), this, &FilePage::onActionPastedir);

        menu.exec(QCursor::pos());
    }
}

void FilePage::onActionUploadFile()
{
    QModelIndex curIndex = ui->treeView->currentIndex();
    QModelIndex index = curIndex.sibling(curIndex.row(), 0); // 获取同一行第0列
    //    if(index.isValid())
    //    {
    //        QMessageBox::information(this, tr("信息"), index.data().toString());
    //    }

    // 无效则不做处理
    if (!curIndex.isValid())
    {
        return;
    }
    auto curItem = treeModel->itemFromIndex(curIndex);
    if (curItem->statusTip() == "1") {
        return;
    }


    QString curFolder = curItem->toolTip();
    cout << "dstFolder : " << curFolder;
    addUploadFiles(curFolder);
}

void FilePage::onActionUploadDir()
{

    QModelIndex curIndex = ui->treeView->currentIndex();
    QModelIndex index = curIndex.sibling(curIndex.row(), 0); // 获取同一行第0列
    //    if(index.isValid())
    //    {
    //        QMessageBox::information(this, tr("信息"), index.data().toString());
    //    }

    // 无效则不做处理
    if (!curIndex.isValid())
    {
        return;
    }
    auto curItem = treeModel->itemFromIndex(curIndex);
    if (curItem->statusTip() == "1") {
        return;
    }


    QString curFolder = curItem->toolTip();
    cout << "dstFolder : " << curFolder;

    addUploadDirs(curFolder, curItem);


}

void FilePage::onActionDownloadDir()
{

    QModelIndex curIndex = ui->treeView->currentIndex();
    QModelIndex index = curIndex.sibling(curIndex.row(), 0); // 获取同一行第0列
    //    if(index.isValid())
    //    {
    //        QMessageBox::information(this, tr("信息"), index.data().toString());
    //    }

    // 无效则不做处理
    if (!curIndex.isValid())
    {
        return;
    }
    auto curItem = treeModel->itemFromIndex(curIndex);
    if (curItem->statusTip() == "1") {
        return;
    }


    QString curFolder = curItem->toolTip();
    QString curFolderName = QDir(curFolder).dirName();
    cout << "wantDownloadFolder : " << curFolder;
    DownloadTask *p = DownloadTask::getInstance();
    if(p == NULL) {
        cout << "DownloadTask::getInstance() == NULL";
        return;
    }
    QString selectDir = QFileDialog::getExistingDirectory();
    cout << "selectDir : " << selectDir;
    for (QString dirName : dirList) {
        if (dirName.startsWith(curFolder)) {
            QString localDir = selectDir + "/" + curFolderName + dirName.mid(curFolder.size());
            //            cout << "localDir : " << localDir;
            QDir curQDir(localDir);
            if (!curQDir.exists()) {
                curQDir.mkpath(localDir);
                cout << "mkpath : " << localDir;
            }
        }
    }


    for (QString filename : fileList) {
        if (filename.startsWith(curFolder)) {
            FileInfo* info = new FileInfo;
            QString onlyFilename = QFileInfo(filename).fileName();
            info->fileName = onlyFilename;
            QString localdir = selectDir + "/" + filename.mid(filename.indexOf(curFolderName));
            cout << "localdir" << localdir;
            int res = p->appendDownloadList(info, localdir, filename); //追加到下载列表
            if(res == -1) {
//                QMessageBox::warning(this, "任务已存在", "任务已经在下载队列中！！！");
            }
            else if(res == -2) { //打开文件失败
                QMessageBox::warning(this, "打开文件失败", curItem->text());
            }
        }

    }

    //    FileInfo* info = new FileInfo;
    //    info->fileName = curItem->text();
    //    int res = p->appendDownloadList(info, selectDir + "/" + curItem->text(), curFile); //追加到下载列表
    //    if(res == -1) {
    //        QMessageBox::warning(this, "任务已存在", "任务已经在下载队列中！！！");
    //    }
    //    else if(res == -2) { //打开文件失败
    //        m_cm.writeRecord("wpy", curItem->text(), "010"); //下载文件失败，记录
    //    }

}

void FilePage::onActionDownloadFile()
{

    QModelIndex curIndex = ui->treeView->currentIndex();
    QModelIndex index = curIndex.sibling(curIndex.row(), 0); // 获取同一行第0列
    //    if(index.isValid())
    //    {
    //        QMessageBox::information(this, tr("信息"), index.data().toString());
    //    }

    if (!curIndex.isValid())
    {
        return;
    }
    auto curItem = treeModel->itemFromIndex(curIndex);
    if (curItem->statusTip() == "0") {
        return;
    }


    QString curFile = curItem->toolTip();
    cout << "wantDownloadFile : " << curFile;
    DownloadTask *p = DownloadTask::getInstance();
    if(p == NULL) {
        cout << "DownloadTask::getInstance() == NULL";
        return;
    }
    QString selectDir = QFileDialog::getExistingDirectory();
    FileInfo* info = new FileInfo;
    info->fileName = curItem->text();
    int res = p->appendDownloadList(info, selectDir + "/" + curItem->text(), curFile); //追加到下载列表
    if(res == -1) {
        QMessageBox::warning(this, "任务已存在", "任务已经在下载队列中！！！");
    }
}


void FilePage::onActionRmdir()
{
    QModelIndex curIndex = ui->treeView->currentIndex();
    QModelIndex index = curIndex.sibling(curIndex.row(), 0); // 获取同一行第0列
    //    if(index.isValid())
    //    {
    //        QMessageBox::information(this, tr("信息"), index.data().toString());
    //    }

    // 无效则不做处理
    if (!curIndex.isValid())
    {
        return;
    }
    auto curItem = treeModel->itemFromIndex(curIndex);
    //    if (curItem->statusTip() == "1") {
    //        return;
    //    }


    QString curFolder = curItem->toolTip();
    cout << "curFolder : " << curFolder;
    LoginInfoInstance *login = LoginInfoInstance::getInstance(); //获取单例
    QByteArray array;
    QMap<QString, QVariant> map;
    map.insert("username", login->getUser());
    if (curItem->statusTip() == "1") {
        map.insert("file_name", curFolder);
        map.insert("task_type", "delete_file");
    } else {
        map.insert("dir_name", curFolder);
        map.insert("task_type", "delete_dir");
    }

    map.insert("token", login->getToken());


    QJsonDocument jsonDocument = QJsonDocument::fromVariant(map);
    if ( jsonDocument.isNull() )
    {
        cout << " jsonDocument.isNull() ";
        array =  "";
    }

    array =  jsonDocument.toJson();
    // 设置登录的url
    QNetworkRequest request;
    QString url = QString("http://%1:%2/cgi-bin/src/Windows-other.cgi").arg(login->getIp()).arg(login->getPort());
    request.setUrl(QUrl(url));
    // 请求头信息
    request.setHeader(QNetworkRequest::ContentTypeHeader, QVariant("application/json"));
    request.setHeader(QNetworkRequest::ContentLengthHeader, QVariant(array.size()));
    // 向服务器发送post请求
    QNetworkReply* reply = m_manager->post(request, array);
    cout << "post url:" << url << "post data: " << array;

    // 接收服务器发回的http响应消息
    connect(reply, &QNetworkReply::finished, [=]()
    {
        // 出错了
        if (reply->error() != QNetworkReply::NoError)
        {
            cout << reply->errorString();
            //释放资源
            reply->deleteLater();
            return;
        }

        // 将server回写的数据读出
        //        QByteArray json = reply->readAll();
        QByteArray jsonData = reply->readAll();
        QJsonParseError error;
        QJsonDocument doc = QJsonDocument::fromJson(jsonData, &error);
        int result = -1;
        if (error.error == QJsonParseError::NoError)
        {
            if (doc.isNull() || doc.isEmpty())
            {
                cout << "doc.isNull() || doc.isEmpty()";
            }

            if( doc.isObject() )
            {
                // 取得最外层这个大对象
                QJsonObject obj = doc.object();
                result = obj.value( "result" ).toInt();
            }
        }
        if (curItem->statusTip() == "0") {
            if( result == 0 )
            {
                cout << "删除文件夹成功";
                // 实例化一个要添加的结点
                auto parentItem = curItem->parent();
                // 如果父结点无效，则当前结点是顶级结点,直接使用model操作
                if (!parentItem)
                {
                    treeModel->takeRow(curItem->row());
                }
                else
                {
                    parentItem->takeRow(curItem->row());
                }
            }
            else if (result == 1)
            {
                QMessageBox::warning(this, "删除文件夹失败", "要删除的目录不存在");
            }
            else if (result == 2)
            {
                QMessageBox::warning(this, "删除文件夹失败", "未知错误");
            } else if (result == 3)
            {
                QMessageBox::warning(this, "删除文件夹失败", "用户认证失败");
            }
        } else {
            if( result == 0 )
            {
                cout << "删除文件成功";
                // 实例化一个要添加的结点
                auto parentItem = curItem->parent();
                // 如果父结点无效，则当前结点是顶级结点,直接使用model操作
                if (!parentItem)
                {
                    treeModel->takeRow(curItem->row());
                }
                else
                {
                    parentItem->takeRow(curItem->row());
                }
            }
            else if (result == 1)
            {
                QMessageBox::warning(this, "删除文件失败", "要删除的文件不存在");
            }else if (result == 2)
            {
                QMessageBox::warning(this, "删除文件失败", "用户认证失败");
            }
        }
        reply->deleteLater(); //释放资源
    });
}

void FilePage::onActionCopydir()
{
    QModelIndex curIndex = ui->treeView->currentIndex();
    QModelIndex index = curIndex.sibling(curIndex.row(), 0); // 获取同一行第0列
    //    if(index.isValid())
    //    {
    //        QMessageBox::information(this, tr("信息"), index.data().toString());
    //    }

    if (!curIndex.isValid())
    {
        return;
    }
    auto curItem = treeModel->itemFromIndex(curIndex);



    QString curFolder = curItem->toolTip();
    cout << "curFolder statusTip() : " << curItem->statusTip();
    if (curItem->statusTip() == "0") {
        curDirType = "copy_dir";
    } else {
        curDirType = "copy_file";
    }

    curCopyDir = curFolder;
    cout << "curCopyDir : " << curCopyDir;
}

void FilePage::onActionCutdir()
{
    QModelIndex curIndex = ui->treeView->currentIndex();
    QModelIndex index = curIndex.sibling(curIndex.row(), 0); // 获取同一行第0列
    //    if(index.isValid())
    //    {
    //        QMessageBox::information(this, tr("信息"), index.data().toString());
    //    }

    if (!curIndex.isValid())
    {
        return;
    }
    auto curItem = treeModel->itemFromIndex(curIndex);
    //    if (curItem->statusTip() == "1") {
    //        return;
    //    }
    cout << "curFolder statusTip() : " << curItem->statusTip();
    if (curItem->statusTip() == "0") {
        curDirType = "cut_dir";
    } else {
        curDirType = "cut_file";
    }
    QString curFolder = curItem->toolTip();
    curCopyDir = curFolder;
    cout << "curCutDir : " << curCopyDir;
}

void FilePage::onActionPastedir()
{
    QModelIndex curIndex = ui->treeView->currentIndex();
    QModelIndex index = curIndex.sibling(curIndex.row(), 0); // 获取同一行第0列
    //    if(index.isValid())
    //    {
    //        QMessageBox::information(this, tr("信息"), index.data().toString());
    //    }

    // 无效则不做处理
    if (!curIndex.isValid())
    {
        return;
    }
    auto curItem = treeModel->itemFromIndex(curIndex);
    if (curItem->statusTip() == QString(1)) {
        return;
    }

    if (curDirType == "") {
        return;
    }

    QString curFolder = curItem->toolTip();
    cout << "curFolder : " << curFolder;
    LoginInfoInstance *login = LoginInfoInstance::getInstance(); //获取单例
    QByteArray array;
    QMap<QString, QVariant> map;
    map.insert("username", login->getUser());

    if (curDirType == "copy_dir") {
        map.insert("task_type", "copy_dir");
        map.insert("dir_name", curCopyDir);
        map.insert("dst_dir_name", curFolder);
    } else if (curDirType == "cut_dir") {
        map.insert("task_type", "cut_dir");
        map.insert("dst_dir_name", curFolder);
        map.insert("dir_name", curCopyDir);
    } else if (curDirType == "copy_file") {
        map.insert("task_type", "copy_file");
        map.insert("file_name", curCopyDir);
        map.insert("dir_name", curFolder);
    } else if (curDirType == "cut_file") {
        map.insert("task_type", "cut_file");
        map.insert("file_name", curCopyDir);
        map.insert("dir_name", curFolder);
    }

    map.insert("token", login->getToken());

    /*json数据如下
                                {
                                    user:xxxx,
                                    pwd:xxx
                                }
                            */

    QJsonDocument jsonDocument = QJsonDocument::fromVariant(map);
    if ( jsonDocument.isNull() )
    {
        cout << " jsonDocument.isNull() ";
        array =  "";
    }

    array =  jsonDocument.toJson();
    // 设置登录的url
    QNetworkRequest request;
    QString url = QString("http://%1:%2/cgi-bin/src/Windows-other.cgi").arg(login->getIp()).arg(login->getPort());
    request.setUrl(QUrl(url));
    // 请求头信息
    request.setHeader(QNetworkRequest::ContentTypeHeader, QVariant("application/json"));
    request.setHeader(QNetworkRequest::ContentLengthHeader, QVariant(array.size()));
    // 向服务器发送post请求
    QNetworkReply* reply = m_manager->post(request, array);
    cout << "post url:" << url << "post data: " << array;

    // 接收服务器发回的http响应消息
    connect(reply, &QNetworkReply::finished, [=]()
    {
        // 出错了
        if (reply->error() != QNetworkReply::NoError)
        {
            cout << reply->errorString();
            //释放资源
            reply->deleteLater();
            return;
        }

        // 将server回写的数据读出
        //        QByteArray json = reply->readAll();
        QByteArray jsonData = reply->readAll();
        QJsonParseError error;
        QJsonDocument doc = QJsonDocument::fromJson(jsonData, &error);
        int result = -1;
        if (error.error == QJsonParseError::NoError)
        {
            if (doc.isNull() || doc.isEmpty())
            {
                cout << "doc.isNull() || doc.isEmpty()";
            }

            if( doc.isObject() )
            {
                // 取得最外层这个大对象
                QJsonObject obj = doc.object();
                result = obj.value( "result" ).toInt();
            }
        }

        if (curDirType == "copy_dir" || curDirType == "cut_dir") {
            if( result == 0 )
            {
                cout << "粘贴文件夹成功";
            }
            else if (result == 1)
            {
                QMessageBox::warning(this, "复制文件夹失败", "要复制的目录不存在");
            }
            else if (result == 2)
            {
                QMessageBox::warning(this, "复制文件夹失败", "目标目录不存在");
            }
            else if (result == 3)
            {
                QMessageBox::warning(this, "复制文件夹失败", "未知错误");
            } else if (result == 4)
            {
                QMessageBox::warning(this, "复制文件夹失败", "用户认证失败");
            }
            else if (result == 5)
            {
                QMessageBox::warning(this, "复制文件夹失败", "不能将父目录剪切到子目录");
            }
        }

        if (curDirType == "copy_file" || curDirType == "cut_file") {
            if( result == 0 )
            {
                cout << "粘贴文件成功";
                // 实例化一个要添加的结点
            }
            else if (result == 2)
            {
                QMessageBox::warning(this, "删除文件夹失败", "目标目录不存在");
            }
            else if (result == 3)
            {
                QMessageBox::warning(this, "删除文件夹失败", "要复制的文件或目录不存在");
            } else if (result == 4)
            {
                QMessageBox::warning(this, "删除文件夹失败", "用户认证失败");
            }
        }
        if (curDirType == "cut_dir" || curDirType == "cut_file") {
            curCopyDir = "";
            curDirType = "";
        }
        reply->deleteLater(); //释放资源
    });
}

void FilePage::mkdir(QStandardItem* curItem, QString newFolderPath, QString newFolderName)
{
    cout << "newFolderPath : " << newFolderPath << " newFolderName : " << newFolderName;
    LoginInfoInstance *login = LoginInfoInstance::getInstance(); //获取单例
    QByteArray array;
    QMap<QString, QVariant> map;
    map.insert("username", login->getUser());
    map.insert("dir_name", newFolderPath);
    map.insert("task_type", "mkdir");
    map.insert("token", login->getToken());

    /*json数据如下
                                {
                                    user:xxxx,
                                    pwd:xxx
                                }
                            */

    QJsonDocument jsonDocument = QJsonDocument::fromVariant(map);
    if ( jsonDocument.isNull() )
    {
        cout << " jsonDocument.isNull() ";
        array =  "";
    }

    array =  jsonDocument.toJson();
    // 设置登录的url
    QNetworkRequest request;
    QString url = QString("http://%1:%2/cgi-bin/src/Windows-other.cgi").arg(login->getIp()).arg(login->getPort());
    request.setUrl(QUrl(url));
    // 请求头信息
    request.setHeader(QNetworkRequest::ContentTypeHeader, QVariant("application/json"));
    request.setHeader(QNetworkRequest::ContentLengthHeader, QVariant(array.size()));
    // 向服务器发送post请求
    QNetworkReply* reply = m_manager->post(request, array);
    cout << "post url:" << url << "post data: " << array;

    QTimer timer;
    timer.setInterval(30000);  // 设置超时时间 30 秒
    timer.setSingleShot(true);  // 单次触发
    QEventLoop loop;
    connect(&timer, &QTimer::timeout, &loop, &QEventLoop::quit);
    connect(reply, &QNetworkReply::finished, &loop, &QEventLoop::quit);
    timer.start();
    loop.exec();  // 启动事件循环


    if (timer.isActive()) {  // 处理响应
        timer.stop();
        // 接收服务器发回的http响应消息
        //    connect(reply, &QNetworkReply::finished, [=]()
        //    {
        // 出错了
        if (reply->error() != QNetworkReply::NoError)
        {
            cout << reply->errorString();
            //释放资源
            reply->deleteLater();
            return;
        }

        // 将server回写的数据读出
        //        QByteArray json = reply->readAll();
        QByteArray jsonData = reply->readAll();
        QJsonParseError error;
        QJsonDocument doc = QJsonDocument::fromJson(jsonData, &error);
        int result = -1;
        if (error.error == QJsonParseError::NoError)
        {
            if (doc.isNull() || doc.isEmpty())
            {
                cout << "doc.isNull() || doc.isEmpty()";
            }

            if( doc.isObject() )
            {
                // 取得最外层这个大对象
                QJsonObject obj = doc.object();
                result = obj.value( "result" ).toInt();
            }
        }
        if( result == 0 )
        {
            cout << "创建文件夹成功";
            // 实例化一个要添加的结点
            QStandardItem* item = new QStandardItem(newFolderName);
            item->setIcon(QIcon(":/images/file-folder.jpeg"));
            item->setToolTip(newFolderPath);
            item->setStatusTip("0");
            // 当前结点
            // 添加到子结点
            curItem->appendRow(item);

            // 设置添加的结点为当前结点
            ui->treeView->setCurrentIndex(item->index());
        }
        else if (result == 2)
        {
            QMessageBox::warning(this, "创建文件夹失败", "父目录不存在");
        } else if (result == 3)
        {
            QMessageBox::warning(this, "创建文件夹失败", "用户认证失败");
        }

        reply->deleteLater(); //释放资源
        //    });
    }else {  // 处理超时
        //disconnect(pReply, &QNetworkReply::finished, &loop, &QEventLoop::quit);
        reply->abort();
        reply->deleteLater();
        cout << "Timeout";
    }

}


void FilePage::onActionMkdir()
{
    QModelIndex curIndex = ui->treeView->currentIndex();
    QModelIndex index = curIndex.sibling(curIndex.row(), 0); // 获取同一行第0列
    //    if(index.isValid())
    //    {
    //        QMessageBox::information(this, tr("信息"), index.data().toString());
    //    }

    // 无效则不做处理
    if (!curIndex.isValid())
    {
        return;
    }
    auto curItem = treeModel->itemFromIndex(curIndex);
    if (curItem->statusTip() == "1") {
        return;
    }

    bool ok;
    QString newFolderName = QInputDialog::getText(this, tr("创建文件夹"),tr("请输入新文件夹名称"), QLineEdit::Normal, 0, &ok);
    if (!ok || newFolderName.isEmpty())
    {
        return;
    }


    QString curFolder = curItem->toolTip();
    cout << "curFolder : " << curFolder;

    QString newFolderPath;
    if (curFolder == "/") {
        newFolderPath =  "/" + newFolderName;
    } else {
        newFolderPath = curFolder + "/" + newFolderName;
    }

    cout << "newFolderPath : " << newFolderPath << endl;

    mkdir(curItem, newFolderPath, newFolderName);
}

void FilePage::onActionRename()
{
    QModelIndex curIndex = ui->treeView->currentIndex();
    QModelIndex index = curIndex.sibling(curIndex.row(), 0);
    //    if(index.isValid())
    //    {
    //        QMessageBox::information(this, tr("信息"), index.data().toString());
    //    }

    // 无效则不做处理
    if (!curIndex.isValid())
    {
        return;
    }
    auto curItem = treeModel->itemFromIndex(curIndex);
    if (curItem->statusTip() == "0") {
        return;
    }

    bool ok;
    QString newFileName = QInputDialog::getText(this, tr("文件重命名"),tr("请输入新文件名称"), QLineEdit::Normal, 0, &ok);
    if (!ok || newFileName.isEmpty())
    {
        return;
    }


    QString curFileName = curItem->toolTip();
    cout << "curFileName : " << curFileName;


    cout << "curFileName : " << curFileName << " newFileName : " << newFileName;
    LoginInfoInstance *login = LoginInfoInstance::getInstance(); //获取单例
    QByteArray array;
    QMap<QString, QVariant> map;
    map.insert("username", login->getUser());
    map.insert("file_name", curFileName);
    map.insert("new_name", newFileName);
    map.insert("task_type", "file_rename");
    map.insert("token", login->getToken());

    /*json数据如下
                                {
                                    user:xxxx,
                                    pwd:xxx
                                }
                            */

    QJsonDocument jsonDocument = QJsonDocument::fromVariant(map);
    if ( jsonDocument.isNull() )
    {
        cout << " jsonDocument.isNull() ";
        array =  "";
    }

    array =  jsonDocument.toJson();
    // 设置登录的url
    QNetworkRequest request;
    QString url = QString("http://%1:%2/cgi-bin/src/Windows-other.cgi").arg(login->getIp()).arg(login->getPort());
    request.setUrl(QUrl(url));
    // 请求头信息
    request.setHeader(QNetworkRequest::ContentTypeHeader, QVariant("application/json"));
    request.setHeader(QNetworkRequest::ContentLengthHeader, QVariant(array.size()));
    // 向服务器发送post请求
    QNetworkReply* reply = m_manager->post(request, array);
    cout << "post url:" << url << "post data: " << array;

    // 接收服务器发回的http响应消息
    connect(reply, &QNetworkReply::finished, [=]()
    {
        // 出错了
        if (reply->error() != QNetworkReply::NoError)
        {
            cout << reply->errorString();
            //释放资源
            reply->deleteLater();
            return;
        }

        // 将server回写的数据读出
        //        QByteArray json = reply->readAll();
        QByteArray jsonData = reply->readAll();
        QJsonParseError error;
        QJsonDocument doc = QJsonDocument::fromJson(jsonData, &error);
        int result = -1;
        if (error.error == QJsonParseError::NoError)
        {
            if (doc.isNull() || doc.isEmpty())
            {
                cout << "doc.isNull() || doc.isEmpty()";
            }

            if( doc.isObject() )
            {
                // 取得最外层这个大对象
                QJsonObject obj = doc.object();
                result = obj.value( "result" ).toInt();
            }
        }
        if( result == 0 )
        {
            cout << "文件改名成功";
            curItem->setText(newFileName);
            QString parentToolTip = curItem->parent()->toolTip();
            QString newToolTop;
            if (parentToolTip == "/") {
                newToolTop =  "/" + newFileName;
            } else {
                newToolTop = parentToolTip + "/" + newFileName;
            }

            curItem->setToolTip(newToolTop);
            cout << "set new ToolTip : " << newToolTop;

        }
        else if (result == 1)
        {
            QMessageBox::warning(this, "文件改名失败", "要改名的文件不存在");
        }
        else if (result == 2)
        {
            QMessageBox::warning(this, "文件改名失败", "已存在新文件名的同名文件");
        }
        else if (result == 3)
        {
            QMessageBox::warning(this, "创建文件夹失败", "用户认证失败");
        }

        reply->deleteLater(); //释放资源
    });
}



